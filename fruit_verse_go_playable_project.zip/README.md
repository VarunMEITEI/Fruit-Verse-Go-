# Fruit Verse Go — Playable Android prototype

This Flutter project contains a local, playable fruit-collecting loop plus optional AR and room-based online features.

## Play now (no ARCore or backend required)

- Open **Collect** and tap **SEARCH FOR A FRUIT**. Each hunt awards a randomly selected fruit. Common fruits appear more often; rarer fruits award more VCoins.
- Open **Inventory** to see fruit quantities. Tap **Sell** to sell one copy for half its listed reward (minimum 1 VCoin).
- Coins, level, player name, inventory and recent activity save on the device with SharedPreferences.
- Duplicate fruits are supported in local inventory and are preserved by the room/trading data model.

## Optional AR camera mode

- Open **Collect → OPEN AR CAMERA**. Aim at a well-lit floor or table, wait for a detected plane, and tap to place a fruit. Move slowly around it, then tap the fruit to collect it.
- This requires an Android phone supported by Google ARCore and Google Play Services for AR. The non-AR Quick Hunt mode remains playable if AR is unsupported or unavailable.
- AR objects are local to each phone. They are not shared world anchors.

## Online rooms and fruit trading

The **Friends** tab can create/join a 6-character room, list players, and send/accept/decline fruit-for-fruit trade offers. It requires a Firebase project configured inside **Friends → Connection settings**.

1. Create a Firebase project and a Realtime Database.
2. Enable Anonymous sign-in in Firebase Authentication.
3. In the app's **Friends → Connection settings**, enter the Realtime Database URL and Firebase Web API key.
4. Configure the database rules to restrict room membership, player data and trade writes before using this publicly. The prototype's client-side REST operations are not a cheat-proof trading authority. For a public game, use trusted server-side trade processing and restrictive security rules; do not use unrestricted authenticated read/write rules in production.

When connected, inventory changes from local hunts/sales are sent to the current player's room profile. Only the inventory and trades sync; real-world AR positions, GPS spawns, chat, and a trusted global leaderboard are not implemented.

## Admin panel

The **Admin** tab appears when the local profile name is `VarunMEITEI`. It allows selecting a fruit to spawn in AR and shows local demo ban/admin lists. These controls are not server-enforced. A public release must verify the owner's Firebase UID or a server-issued claim, not a display name, before allowing spawn/ban/promotion commands.

## Build the APK using GitHub Actions from an Android phone

1. Upload this ZIP's contents as `collects_go_project.zip` at the root of your GitHub repository (replace the old ZIP).
2. Replace `.github/workflows/build.yml` with the companion `build_fruit_verse_go_playable.yml` file's contents.
3. Commit both changes. GitHub Actions will create an Android release APK and upload it as `fruit-verse-go-playable-apk` if the build succeeds.
4. Open the workflow run, download the artifact ZIP, extract `app-release.apk`, and install it on your phone.

Builds are not verified until the GitHub Actions run finishes successfully.
