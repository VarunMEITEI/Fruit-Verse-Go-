import 'dart:math' as math;
import 'multiplayer.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:ar_flutter_plugin/ar_flutter_plugin.dart';
import 'package:ar_flutter_plugin/managers/ar_session_manager.dart';
import 'package:ar_flutter_plugin/managers/ar_object_manager.dart';
import 'package:ar_flutter_plugin/managers/ar_anchor_manager.dart';
import 'package:ar_flutter_plugin/managers/ar_location_manager.dart';
import 'package:ar_flutter_plugin/models/ar_anchor.dart';
import 'package:ar_flutter_plugin/models/ar_node.dart';
import 'package:ar_flutter_plugin/models/ar_hittest_result.dart';
import 'package:ar_flutter_plugin/datatypes/config_planedetection.dart';
import 'package:ar_flutter_plugin/datatypes/hittest_result_types.dart';
import 'package:ar_flutter_plugin/datatypes/node_types.dart';
import 'package:vector_math/vector_math_64.dart';

void main() => runApp(const CollectsGoApp());

const lime = Color(0xFF9BFF00);
const coral = Color(0xFFFF555B);
const ink = Color(0xFF14252A);
const purple = Color(0xFF6D4AFF);

class CollectsGoApp extends StatelessWidget {
  const CollectsGoApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "Fruit Verse Go",
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: lime),
        scaffoldBackgroundColor: const Color(0xFFF5FAFF),
        useMaterial3: true,
        fontFamily: 'Roboto',
      ),
      home: const GameHome(),
    );
  }
}

class FruitItem {
  FruitItem(this.name, this.rarity, this.emoji, this.reward);
  final String name;
  final String rarity;
  final String emoji;
  final int reward;
}

const fruitCatalog = <FruitItem>[
  FruitItem('Stone Fruit', 'Common', '🪨', 5),
  FruitItem('Bloom Fruit', 'Rare', '🌸', 25),
  FruitItem('Thunder Fruit', 'Epic', '⚡', 60),
  FruitItem('Solar Fruit', 'Legendary', '☀️', 150),
  FruitItem('Nebula Fruit', 'Mythic', '🌌', 400),
];

class GameHome extends StatefulWidget {
  const GameHome({super.key});
  @override
  State<GameHome> createState() => _GameHomeState();
}

class _GameHomeState extends State<GameHome> {
  int tab = 0;
  int coins = 250;
  int level = 1;
  String playerName = 'Player';
  final List<String> owned = ['Stone Fruit'];
  final List<String> activity = ['Welcome to Fruit Verse Go!'];
  final Set<String> bannedPlayers = {};
  final Set<String> admins = {'VarunMEITEI'};
  String adminSelectedFruit = fruitCatalog.first.name;

  @override
  void initState() {
    super.initState();
    _loadSavedGame();
  }

  Future<void> _loadSavedGame() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      if (!mounted) return;
      setState(() {
        coins = prefs.getInt('fvg_coins') ?? coins;
        level = prefs.getInt('fvg_level') ?? level;
        playerName = prefs.getString('fvg_player_name') ?? prefs.getString('mp_player_name') ?? playerName;
        if (prefs.containsKey('fvg_inventory')) {
          owned
            ..clear()
            ..addAll(prefs.getStringList('fvg_inventory') ?? <String>[]);
        }
        activity
          ..clear()
          ..addAll(prefs.getStringList('fvg_activity') ?? <String>['Welcome to Fruit Verse Go!']);
        if (activity.isEmpty) activity.add('Welcome back to Fruit Verse Go!');
      });
    } catch (_) {
      // The game remains playable even if local storage is unavailable.
    }
  }

  Future<void> _saveGame() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setInt('fvg_coins', coins);
      await prefs.setInt('fvg_level', level);
      await prefs.setString('fvg_player_name', playerName);
      await prefs.setStringList('fvg_inventory', List<String>.from(owned));
      await prefs.setStringList('fvg_activity', activity.take(30).toList());
    } catch (_) {
      // Local play should not fail if preferences cannot be written.
    }
  }

  void _quickHunt() {
    // Weighted rarity roll: common fruit is frequent, mythical fruit is rare.
    final roll = math.Random().nextInt(100);
    final index = roll < 40 ? 0 : roll < 68 ? 1 : roll < 86 ? 2 : roll < 97 ? 3 : 4;
    collect(fruitCatalog[index]);
  }

  void collect(FruitItem item) {
    setState(() {
      owned.add(item.name);
      coins += item.reward;
      level = 1 + (owned.length ~/ 3);
      activity.insert(0, 'Collected ${item.name} • +${item.reward} VCoins');
    });
    _saveGame();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('${item.emoji} ${item.name} collected! +${item.reward} VCoins')),
    );
  }

  void _sellFruit(FruitItem item) {
    final index = owned.indexOf(item.name);
    if (index < 0) return;
    final int sale = item.reward ~/ 2 < 1 ? 1 : item.reward ~/ 2;
    setState(() {
      owned.removeAt(index);
      coins += sale;
      activity.insert(0, 'Sold ${item.name} • +$sale VCoins');
    });
    _saveGame();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Sold ${item.name} for $sale VCoins.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homePage(),
      _collectPage(),
      _mapPage(),
      _inventoryPage(),
      _leaderboardPage(),
      MultiplayerView(playerName: playerName, initialOwned: owned.toList(), onInventoryChanged: _replaceOwned),
      if (playerName.trim().toLowerCase() == 'varunmeitei') _adminPage(),
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Row(
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: Image.asset("assets/fruit_verse_go_logo.png", width: 36, height: 36, fit: BoxFit.cover),
            ),
            const SizedBox(width: 8),
            const Expanded(child: Text("Fruit Verse Go", style: TextStyle(fontWeight: FontWeight.w900, color: ink))),
          ],
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 8),
            child: Center(child: Text('🪙 $coins', style: const TextStyle(fontWeight: FontWeight.w900, color: ink))),
          ),
          IconButton(onPressed: _showTrade, icon: const Icon(Icons.swap_horiz_rounded), tooltip: 'Trade'),
        ],
      ),
      body: IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'Collect'),
          NavigationDestination(icon: Icon(Icons.map_outlined), label: 'Map'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), label: 'Inventory'),
          NavigationDestination(icon: Icon(Icons.emoji_events_outlined), label: 'Leaderboard'),
          NavigationDestination(icon: Icon(Icons.groups_outlined), selectedIcon: Icon(Icons.groups), label: 'Friends'),
          if (playerName.trim().toLowerCase() == 'varunmeitei') const NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), selectedIcon: Icon(Icons.admin_panel_settings), label: 'Admin'),
        ],
      ),
    );
  }

  Widget _adminPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: ink, borderRadius: BorderRadius.circular(22)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Icon(Icons.admin_panel_settings, color: lime, size: 30), SizedBox(width: 10), Expanded(child: Text('ADMIN PANEL', style: TextStyle(color: Colors.white, fontSize: 23, fontWeight: FontWeight.w900)))]),
          SizedBox(height: 8),
          Text('Owner: VarunMEITEI', style: TextStyle(color: lime, fontWeight: FontWeight.bold)),
          SizedBox(height: 8),
          Text('Prototype controls only. Spawn, ban and admin-role changes below are stored only in this app session; they do not affect other players online yet.', style: TextStyle(color: Colors.white70)),
        ]),
      ),
      const SizedBox(height: 16),
      const Text('SPAWN ANY FRUIT', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      DropdownButtonFormField<String>(
        value: adminSelectedFruit,
        decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'Choose fruit'),
        items: fruitCatalog.map((f) => DropdownMenuItem(value: f.name, child: Text('${f.emoji} ${f.name} • ${f.rarity}'))).toList(),
        onChanged: (v) { if (v != null) setState(() => adminSelectedFruit = v); },
      ),
      const SizedBox(height: 8),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: lime, foregroundColor: ink, padding: const EdgeInsets.symmetric(vertical: 14)),
        icon: const Icon(Icons.add_location_alt), label: const Text('SPAWN SELECTED FRUIT IN AR', style: TextStyle(fontWeight: FontWeight.w900)),
        onPressed: () {
          final fruit = fruitCatalog.firstWhere((f) => f.name == adminSelectedFruit);
          Navigator.of(context).push(MaterialPageRoute(builder: (_) => ARFruitHuntPage(onCollected: collect, forcedFruit: fruit)));
        },
      ),
      const SizedBox(height: 18),
      const Text('PLAYER MODERATION', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      const Text('Demo only: these lists are not sent to the multiplayer server.'),
      const SizedBox(height: 8),
      OutlinedButton.icon(
        icon: const Icon(Icons.block), label: const Text('Ban a player (local demo)'),
        onPressed: () => _adminPlayerDialog(ban: true),
      ),
      OutlinedButton.icon(
        icon: const Icon(Icons.verified_user_outlined), label: const Text('Grant admin (local demo)'),
        onPressed: () => _adminPlayerDialog(ban: false),
      ),
      if (bannedPlayers.isNotEmpty) ...[
        const SizedBox(height: 12), const Text('Locally banned players', style: TextStyle(fontWeight: FontWeight.bold)),
        ...bannedPlayers.map((name) => ListTile(leading: const Icon(Icons.block, color: Colors.red), title: Text(name), trailing: IconButton(icon: const Icon(Icons.undo), tooltip: 'Unban locally', onPressed: () => setState(() => bannedPlayers.remove(name))))),
      ],
      if (admins.isNotEmpty) ...[
        const SizedBox(height: 12), const Text('Local admin list', style: TextStyle(fontWeight: FontWeight.bold)),
        ...admins.map((name) => ListTile(leading: const Icon(Icons.admin_panel_settings, color: Colors.deepPurple), title: Text(name))),
      ],
      const SizedBox(height: 12),
      const Text('Security note: a real online admin panel must verify the owner’s Firebase UID on a trusted backend. A display name alone is not secure, and client-side ban/admin buttons can be bypassed.', style: TextStyle(fontSize: 12, color: Colors.black54)),
    ],
  );

  Future<void> _adminPlayerDialog({required bool ban}) async {
    final controller = TextEditingController();
    final name = await showDialog<String>(context: context, builder: (context) => AlertDialog(
      title: Text(ban ? 'Ban player' : 'Grant admin'),
      content: TextField(controller: controller, autofocus: true, decoration: const InputDecoration(labelText: 'Exact player name', border: OutlineInputBorder())),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, controller.text.trim()), child: const Text('Confirm'))],
    ));
    controller.dispose();
    if (!mounted || name == null || name.isEmpty) return;
    setState(() {
      if (ban) { bannedPlayers.add(name); admins.remove(name); }
      else { admins.add(name); bannedPlayers.remove(name); }
      activity.insert(0, ban ? 'Local demo: banned $name' : 'Local demo: granted admin to $name');
    });
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(ban ? '$name added to local demo ban list.' : '$name added to local demo admins.')));
  }

  Widget _homePage() => ListView(
    padding: const EdgeInsets.fromLTRB(16, 8, 16, 20),
    children: [
      Row(children: [
        CircleAvatar(backgroundColor: lime, child: const Icon(Icons.person, color: ink)),
        const SizedBox(width: 10),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(playerName, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          Text('Level $level • ${owned.toSet().length} fruit types • ${owned.length} fruits'),
          const SizedBox(height: 5),
          ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: (level % 5) / 5, minHeight: 8, color: lime, backgroundColor: const Color(0xFFDDE5EA))),
        ])),
        const SizedBox(width: 8),
        IconButton(onPressed: _editName, icon: const Icon(Icons.edit_outlined), tooltip: 'Change name'),
      ]),
      const SizedBox(height: 12),
      ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Image.asset('assets/collects_go_home.png', fit: BoxFit.fitWidth, width: double.infinity),
      ),
      const SizedBox(height: 12),
      FilledButton.icon(
        style: FilledButton.styleFrom(backgroundColor: lime, foregroundColor: ink, padding: const EdgeInsets.symmetric(vertical: 18), textStyle: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        onPressed: () => setState(() => tab = 1),
        icon: const Icon(Icons.location_on, size: 28),
        label: const Text('GO HUNTING'),
      ),
      const SizedBox(height: 14),
      const Text('Your next discoveries', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 8),
      ...fruitCatalog.take(3).map((f) => Card(child: ListTile(
        leading: Text(f.emoji, style: const TextStyle(fontSize: 30)),
        title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${f.rarity} • +${f.reward} VCoins'),
        trailing: owned.contains(f.name) ? const Icon(Icons.check_circle, color: Colors.green) : const Icon(Icons.chevron_right),
        onTap: () => setState(() => tab = 1),
      ))),
    ],
  );

  Widget _collectPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('AR fruit hunting', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      const Text('Find fruits, build your inventory, earn VCoins, and sell spare fruit. AR is an optional extra on supported phones.'),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), color: ink),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('QUICK HUNT', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: lime)),
          const SizedBox(height: 6),
          const Text('Play immediately without a camera or ARCore. Search for a random fruit; rare fruits give more coins.', style: TextStyle(color: Colors.white70)),
          const SizedBox(height: 12),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: lime, foregroundColor: ink, padding: const EdgeInsets.symmetric(vertical: 15)),
            onPressed: _quickHunt,
            icon: const Icon(Icons.travel_explore),
            label: const Text('SEARCH FOR A FRUIT', style: TextStyle(fontWeight: FontWeight.w900)),
          )),
        ]),
      ),
      const SizedBox(height: 14),
      Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(22), gradient: const LinearGradient(colors: [Color(0xFFE9FFD0), Color(0xFFE6F5FF)])),
        child: Column(children: [
          const Text('📸  OPTIONAL AR HUNT', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          const SizedBox(height: 8),
          const Text('AR requires a compatible Android phone with Google Play Services for AR.'),
          const SizedBox(height: 14),
          SizedBox(width: double.infinity, child: FilledButton.icon(
            style: FilledButton.styleFrom(backgroundColor: lime, foregroundColor: ink, padding: const EdgeInsets.symmetric(vertical: 16)),
            onPressed: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => ARFruitHuntPage(onCollected: collect),
            )),
            icon: const Icon(Icons.camera_alt_rounded),
            label: const Text('OPEN AR CAMERA', style: TextStyle(fontWeight: FontWeight.w900)),
          )),
        ]),
      ),
      const SizedBox(height: 14),
      const Text('Fruit collection', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
      const SizedBox(height: 6),
      ...fruitCatalog.map((f) => Card(child: ListTile(
        leading: CircleAvatar(backgroundColor: _rarityColor(f.rarity).withOpacity(.15), child: Text(f.emoji, style: const TextStyle(fontSize: 24))),
        title: Text(f.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${f.rarity} • +${f.reward} VCoins'),
        trailing: owned.contains(f.name) ? const Icon(Icons.check_circle, color: Colors.green) : const Icon(Icons.camera_alt_outlined),
      ))),
      const SizedBox(height: 8),
      const Text('Safety: scan while standing still in a safe, open place. Never use AR while crossing roads or enter private property to collect a fruit.'),
    ],
  );

  Widget _mapPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      const Text('Spawn map', style: TextStyle(fontSize: 25, fontWeight: FontWeight.w900)),
      const SizedBox(height: 10),
      Container(
        height: 300,
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(24), color: const Color(0xFFE7F5E6)),
        child: Stack(children: [
          Positioned.fill(child: CustomPaint(painter: _MapPainter())),
          const Positioned(left: 35, top: 40, child: _MapPin(color: coral, emoji: '🌸')),
          const Positioned(right: 55, top: 95, child: _MapPin(color: purple, emoji: '⚡')),
          const Positioned(left: 125, bottom: 45, child: _MapPin(color: Color(0xFF52C85A), emoji: '☀️')),
          const Center(child: Icon(Icons.my_location, size: 42, color: ink)),
        ]),
      ),
      const SizedBox(height: 12),
      const Text('Map pins are illustrative in this starter. Real-time spawn coordinates, distance checks and live updates require a location-enabled backend.'),
    ],
  );

  Widget _inventoryPage() => InventoryView(owned: owned, onSell: _sellFruit);

  Widget _leaderboardPage() {
    final rows = [('NovaHunter', 18), (playerName, 12), ('FruitNinja', 9), ('SkySeeker', 6), ('MangoByte', 4)];
    return ListView(padding: const EdgeInsets.all(16), children: [
      const Text('Legendary leaderboard', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
      const Text('Sample scores for preview; online rankings are not connected yet.'),
      const SizedBox(height: 12),
      ...List.generate(rows.length, (i) => Card(child: ListTile(
        leading: CircleAvatar(backgroundColor: i == 0 ? lime : Colors.white, child: Text('${i + 1}', style: const TextStyle(fontWeight: FontWeight.bold))),
        title: Text(rows[i].$1),
        trailing: Text('☀️ ${rows[i].$2}', style: const TextStyle(fontWeight: FontWeight.w900)),
      ))),
      const SizedBox(height: 12),
      const Text('Recent activity', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ...activity.take(6).map((a) => ListTile(leading: const Icon(Icons.history), title: Text(a))),
    ]);
  }

  void _editName() {
    final controller = TextEditingController(text: playerName);
    showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Choose your hunter name'),
      content: TextField(controller: controller, maxLength: 20, decoration: const InputDecoration(hintText: 'Player name')),
      actions: [
        TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () {
          final name = controller.text.trim();
          if (name.isNotEmpty) {
            setState(() {
              playerName = name;
              if (playerName.toLowerCase() != 'varunmeitei' && tab == 6) tab = 0;
            });
            _saveGame();
            SharedPreferences.getInstance().then((prefs) => prefs.setString('mp_player_name', name));
          }
          Navigator.pop(ctx);
        }, child: const Text('Save')),
      ],
    ));
  }

  void _replaceOwned(List<String> fruits) {
    setState(() {
      owned
        ..clear()
        ..addAll(fruits);
      activity.insert(0, 'Inventory updated by a trade');
    });
    _saveGame();
  }

  void _showTrade() {
    setState(() => tab = 5);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Open Friends to trade fruits with players in your room.')),
    );
  }

  Color _rarityColor(String r) => switch (r) {
    'Common' => Colors.blueGrey,
    'Rare' => Colors.green,
    'Epic' => purple,
    'Legendary' => Colors.orange,
    _ => coral,
  };
}


class ARFruitHuntPage extends StatefulWidget {
  const ARFruitHuntPage({super.key, required this.onCollected, this.forcedFruit});
  final ValueChanged<FruitItem> onCollected;
  final FruitItem? forcedFruit;

  @override
  State<ARFruitHuntPage> createState() => _ARFruitHuntPageState();
}

class _ARFruitHuntPageState extends State<ARFruitHuntPage> {
  ARSessionManager? session;
  ARObjectManager? objects;
  ARAnchorManager? anchorsManager;
  final List<ARAnchor> anchors = [];
  final Map<String, ARAnchor> anchorForNode = {};
  final Map<String, FruitItem> fruitForNode = {};
  int placed = 0;
  String status = 'Move your phone slowly to scan the floor or a table.';

  @override
  void dispose() {
    session?.dispose();
    super.dispose();
  }

  void _onARViewCreated(
    ARSessionManager sessionManager,
    ARObjectManager objectManager,
    ARAnchorManager anchorManager,
    ARLocationManager locationManager,
  ) {
    session = sessionManager;
    objects = objectManager;
    anchorsManager = anchorManager;
    sessionManager.onInitialize(
      showFeaturePoints: false,
      showPlanes: true,
      showWorldOrigin: false,
      handleTaps: true,
    );
    objectManager.onInitialize();
    sessionManager.onPlaneOrPointTap = _onSurfaceTapped;
    objectManager.onNodeTap = _onNodeTapped;
  }

  Future<void> _onSurfaceTapped(List<ARHitTestResult> results) async {
    if (anchorsManager == null || objects == null) return;
    ARHitTestResult? hit;
    for (final result in results) {
      if (result.type == ARHitTestResultType.plane) {
        hit = result;
        break;
      }
    }
    if (hit == null) {
      if (mounted) setState(() => status = 'No surface detected yet. Point at a well-lit floor or table and try again.');
      return;
    }

    final anchor = ARPlaneAnchor(transformation: hit.worldTransform);
    final didAddAnchor = await anchorsManager!.addAnchor(anchor);
    if (didAddAnchor != true) {
      if (mounted) setState(() => status = 'Could not place fruit. Try another spot.');
      return;
    }

    final fruit = widget.forcedFruit ?? fruitCatalog[placed % fruitCatalog.length];
    final nodeName = 'collectible_${DateTime.now().microsecondsSinceEpoch}';
    final node = ARNode(
      name: nodeName,
      type: NodeType.localGLTF2,
      uri: 'assets/models/fruit.glb',
      scale: Vector3(0.75, 0.75, 0.75),
      position: Vector3(0.0, 0.08, 0.0),
      rotation: Vector4(0.0, 1.0, 0.0, 0.0),
    );
    final didAddNode = await objects!.addNode(node, planeAnchor: anchor);
    if (didAddNode == true) {
      anchors.add(anchor);
      anchorForNode[nodeName] = anchor;
      fruitForNode[nodeName] = fruit;
      if (mounted) setState(() {
        placed++;
        status = 'Fruit placed! Move around it, then tap the fruit to collect it.';
      });
    } else {
      await anchorsManager!.removeAnchor(anchor);
      if (mounted) setState(() => status = 'Could not load the fruit model. Please retry.');
    }
  }

  Future<void> _onNodeTapped(List<String> nodeNames) async {
    for (final name in nodeNames) {
      final fruit = fruitForNode.remove(name);
      final anchor = anchorForNode.remove(name);
      if (fruit == null || anchor == null) continue;
      await anchorsManager?.removeAnchor(anchor);
      anchors.remove(anchor);
      widget.onCollected(fruit);
      if (mounted) setState(() => status = '${fruit.name} collected! Tap another detected surface to place the next fruit.');
      break;
    }
  }

  Future<void> _clearFruit() async {
    for (final anchor in List<ARAnchor>.from(anchors)) {
      await anchorsManager?.removeAnchor(anchor);
    }
    anchors.clear();
    anchorForNode.clear();
    fruitForNode.clear();
    if (mounted) setState(() {
      placed = 0;
      status = 'Cleared. Scan a surface and tap to place a fruit.';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: const Color(0xFF14252A),
        foregroundColor: Colors.white,
        title: const Text('Fruit Verse Go AR Hunt', style: TextStyle(fontWeight: FontWeight.w900)),
        actions: [IconButton(onPressed: _clearFruit, icon: const Icon(Icons.refresh), tooltip: 'Clear fruits')],
      ),
      body: Stack(children: [
        ARView(
          onARViewCreated: _onARViewCreated,
          planeDetectionConfig: PlaneDetectionConfig.horizontal,
        ),
        Positioned(
          top: 14, left: 14, right: 14,
          child: Container(
            padding: const EdgeInsets.all(13),
            decoration: BoxDecoration(color: Colors.black.withOpacity(.68), borderRadius: BorderRadius.circular(16), border: Border.all(color: lime.withOpacity(.7))),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const Text('🍈 FIND A FRUIT', style: TextStyle(color: lime, fontWeight: FontWeight.w900, fontSize: 17)),
              const SizedBox(height: 4),
              Text(status, style: const TextStyle(color: Colors.white, fontSize: 13)),
              const SizedBox(height: 4),
              Text('Placed: $placed  •  Tap fruit to collect', style: const TextStyle(color: Colors.white70, fontSize: 12)),
            ]),
          ),
        ),
        const Align(
          alignment: Alignment.center,
          child: IgnorePointer(child: Icon(Icons.add, size: 34, color: Colors.white70)),
        ),
        Positioned(
          bottom: 20, left: 20, right: 20,
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(color: Colors.black.withOpacity(.65), borderRadius: BorderRadius.circular(14)),
            child: const Text('1. Aim at a flat surface.  2. Tap to place a fruit.  3. Move around it, then tap the fruit to collect.', textAlign: TextAlign.center, style: TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
          ),
        ),
      ]),
    );
  }
}

class InventoryView extends StatefulWidget {
  const InventoryView({super.key, required this.owned, required this.onSell});
  final List<String> owned;
  final ValueChanged<FruitItem> onSell;
  @override
  State<InventoryView> createState() => _InventoryViewState();
}
class _InventoryViewState extends State<InventoryView> {
  String query = '';
  String rarity = 'All';
  @override
  Widget build(BuildContext context) {
    final items = fruitCatalog.where((f) => widget.owned.contains(f.name) &&
      f.name.toLowerCase().contains(query.toLowerCase()) &&
      (rarity == 'All' || f.rarity == rarity)).toList();
    return Padding(padding: const EdgeInsets.all(16), child: Column(children: [
      Row(children: [
        const Expanded(child: Text('Fruit inventory', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900))),
        Text('${widget.owned.length} total', style: const TextStyle(fontWeight: FontWeight.bold, color: ink)),
      ]),
      const SizedBox(height: 12),
      TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search fruits', border: OutlineInputBorder()), onChanged: (v) => setState(() => query = v)),
      const SizedBox(height: 10),
      DropdownButtonFormField<String>(
        value: rarity, decoration: const InputDecoration(labelText: 'Rarity selector', border: OutlineInputBorder()),
        items: ['All', 'Common', 'Rare', 'Epic', 'Legendary', 'Mythic'].map((r) => DropdownMenuItem(value: r, child: Text(r))).toList(),
        onChanged: (v) => setState(() => rarity = v ?? 'All'),
      ),
      const SizedBox(height: 12),
      Expanded(child: items.isEmpty ? const Center(child: Text('No matching fruits yet. Go to Collect and hunt for one!')) : GridView.builder(
        itemCount: items.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 10, mainAxisSpacing: 10, childAspectRatio: .86),
        itemBuilder: (ctx, i) {
          final item = items[i];
          final count = widget.owned.where((name) => name == item.name).length;
          final sellValue = math.max(1, item.reward ~/ 2);
          return Card(child: Padding(padding: const EdgeInsets.all(8), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            Text(item.emoji, style: const TextStyle(fontSize: 40)),
            const SizedBox(height: 4),
            Text(item.name, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.bold)),
            Text('${item.rarity} • x$count', style: const TextStyle(fontSize: 12)),
            const Spacer(),
            SizedBox(width: double.infinity, child: OutlinedButton(
              onPressed: () => widget.onSell(item),
              style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 4)),
              child: Text('Sell +$sellValue', style: const TextStyle(fontSize: 12)),
            )),
          ])));
        },
      )),
    ]));
  }
}

class _MapPin extends StatelessWidget {
  const _MapPin({required this.color, required this.emoji});
  final Color color;
  final String emoji;
  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(9),
    decoration: BoxDecoration(color: color, shape: BoxShape.circle, boxShadow: const [BoxShadow(color: Colors.black12, blurRadius: 8, offset: Offset(0, 3))]),
    child: Text(emoji, style: const TextStyle(fontSize: 20)),
  );
}

class _MapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final road = Paint()..color = Colors.white..strokeWidth = 22..style = PaintingStyle.stroke..strokeCap = StrokeCap.round;
    final thin = Paint()..color = const Color(0xFFBFE7C4)..strokeWidth = 5..style = PaintingStyle.stroke;
    final p1 = Path()..moveTo(-10, size.height * .25)..cubicTo(size.width * .3, size.height * .2, size.width * .4, size.height * .7, size.width + 10, size.height * .55);
    final p2 = Path()..moveTo(size.width * .2, -10)..cubicTo(size.width * .45, size.height * .3, size.width * .55, size.height * .65, size.width * .7, size.height + 10);
    canvas.drawPath(p1, road); canvas.drawPath(p2, road);
    canvas.drawPath(p1, thin); canvas.drawPath(p2, thin);
  }
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
