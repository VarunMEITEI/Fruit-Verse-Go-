import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

const _mpLime = Color(0xFF9BFF00);
const _mpInk = Color(0xFF14252A);
const List<String> _tradeFruitOptions = ['Stone Fruit', 'Bloom Fruit', 'Thunder Fruit', 'Solar Fruit', 'Nebula Fruit'];

class MultiplayerView extends StatefulWidget {
  const MultiplayerView({super.key, required this.playerName, required this.initialOwned, required this.onInventoryChanged});
  final String playerName;
  final List<String> initialOwned;
  final ValueChanged<List<String>> onInventoryChanged;
  @override
  State<MultiplayerView> createState() => _MultiplayerViewState();
}

class _MultiplayerViewState extends State<MultiplayerView> {
  final _name = TextEditingController(text: 'Player');
  final _room = TextEditingController();
  String _databaseUrl = '';
  String _apiKey = '';
  String? _uid;
  String? _token;
  String? _roomCode;
  Map<String, dynamic> _players = {};
  Map<String, dynamic> _trades = {};
  List<String> _myInventory = [];
  String _status = 'Set up online play to create or join a room.';
  bool _busy = false;
  Timer? _poller;

  @override
  void initState() { super.initState(); _myInventory = List<String>.from(widget.initialOwned); _loadSettings(); }

  @override
  void didUpdateWidget(covariant MultiplayerView oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.playerName != widget.playerName && _roomCode == null) {
      _name.text = widget.playerName;
    }
    final incoming = List<String>.from(widget.initialOwned);
    if (!_sameItems(incoming, _myInventory)) {
      if (_roomCode == null) {
        _myInventory = incoming;
      } else {
        _syncInventory(incoming);
      }
    }
  }

  Future<void> _syncInventory(List<String> inventory) async {
    final code = _roomCode;
    final uid = _uid;
    if (code == null || uid == null || _token == null) return;
    try {
      final response = await http.patch(
        _dbUri('rooms/$code/players/$uid'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'inventory': inventory,
          'name': _name.text.trim().isEmpty ? widget.playerName : _name.text.trim(),
          'updatedAt': DateTime.now().millisecondsSinceEpoch,
        }),
      );
      if (response.statusCode >= 200 && response.statusCode < 300) {
        _myInventory = List<String>.from(inventory);
        await _refreshRoom();
      }
    } catch (_) {
      // Keep local play available when a connection is unavailable.
    }
  }
  @override
  void dispose() { _poller?.cancel(); _name.dispose(); _room.dispose(); super.dispose(); }

  Future<void> _loadSettings() async {
    final p = await SharedPreferences.getInstance();
    if (!mounted) return;
    setState(() {
      _databaseUrl = p.getString('mp_database_url') ?? '';
      _apiKey = p.getString('mp_api_key') ?? '';
      _name.text = p.getString('mp_player_name') ?? widget.playerName;
    });
  }

  String get _base => _databaseUrl.trim().replaceAll(RegExp(r'/+$'), '');
  Future<void> _settings() async {
    final url = TextEditingController(text: _databaseUrl);
    final key = TextEditingController(text: _apiKey);
    final name = TextEditingController(text: _name.text);
    final ok = await showDialog<bool>(context: context, builder: (context) => AlertDialog(
      title: const Text('Online multiplayer setup'),
      content: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, children: [
        const Text('Create a Firebase project with Realtime Database and enable Anonymous sign-in. Paste your database URL and Web API key below.'),
        const SizedBox(height: 12),
        TextField(controller: name, decoration: const InputDecoration(labelText: 'Player name', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: url, decoration: const InputDecoration(labelText: 'Realtime Database URL', hintText: 'https://your-project-default-rtdb.firebaseio.com', border: OutlineInputBorder())),
        const SizedBox(height: 10),
        TextField(controller: key, decoration: const InputDecoration(labelText: 'Firebase Web API key', border: OutlineInputBorder())),
      ])),
      actions: [TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')), FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Save'))],
    ));
    if (ok != true) return;
    final p = await SharedPreferences.getInstance();
    await p.setString('mp_database_url', url.text.trim());
    await p.setString('mp_api_key', key.text.trim());
    await p.setString('mp_player_name', name.text.trim().isEmpty ? 'Player' : name.text.trim());
    setState(() { _databaseUrl = url.text.trim(); _apiKey = key.text.trim(); _name.text = name.text.trim().isEmpty ? 'Player' : name.text.trim(); _status = 'Settings saved. Create or join a room.'; });
  }

  Future<void> _ensureSignedIn() async {
    if (_token != null && _uid != null) return;
    if (_apiKey.isEmpty || _base.isEmpty) throw Exception('Tap the settings button and add your Firebase URL and API key first.');
    final uri = Uri.parse('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=$_apiKey');
    final response = await http.post(uri, headers: {'Content-Type':'application/json'}, body: jsonEncode({'returnSecureToken': true}));
    if (response.statusCode < 200 || response.statusCode >= 300) throw Exception('Firebase sign-in failed. Check the API key and enable Anonymous sign-in.');
    final data = jsonDecode(response.body) as Map<String, dynamic>;
    _uid = data['localId'] as String?;
    _token = data['idToken'] as String?;
    if (_uid == null || _token == null) throw Exception('Firebase did not return a sign-in token.');
  }

  Uri _dbUri(String path) => Uri.parse('$_base/$path.json?auth=$_token');
  Future<void> _createRoom() async {
    final code = List.generate(6, (_) => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'[Random.secure().nextInt(32)]).join();
    await _joinRoom(code, create: true);
  }
  Future<void> _joinPressed() async => _joinRoom(_room.text.trim().toUpperCase());
  Future<void> _joinRoom(String code, {bool create = false}) async {
    if (code.length != 6) { setState(() => _status = 'Room codes must be 6 characters.'); return; }
    setState(() { _busy = true; _status = 'Connecting…'; });
    try {
      await _ensureSignedIn();
      final roomUri = _dbUri('rooms/$code');
      final existing = await http.get(roomUri);
      if (existing.statusCode < 200 || existing.statusCode >= 300) throw Exception('Could not reach the multiplayer database. Check your URL and database rules.');
      if (existing.body != 'null' && create) throw Exception('That room code already exists. Try again.');
      if (existing.body == 'null' && !create) throw Exception('Room not found. Check the code or create a new room.');
      if (existing.body == 'null') {
        final created = await http.put(roomUri, headers: {'Content-Type':'application/json'}, body: jsonEncode({'createdAt': DateTime.now().millisecondsSinceEpoch, 'players': {}}));
        if (created.statusCode < 200 || created.statusCode >= 300) throw Exception('Could not create room. Check database rules.');
      }
      final playerUri = _dbUri('rooms/$code/players/$_uid');
      final priorResponse = await http.get(playerUri);
      if (priorResponse.statusCode < 200 || priorResponse.statusCode >= 300) throw Exception('Could not load your player profile. Check database rules.');
      Map<String, dynamic> prior = {};
      if (priorResponse.body != 'null') {
        final decoded = jsonDecode(priorResponse.body);
        if (decoded is Map) prior = Map<String, dynamic>.from(decoded);
      }
      final savedInventory = prior['inventory'];
      final inventory = savedInventory is List
          ? savedInventory.map((v) => v.toString()).toList()
          : List<String>.from(_myInventory);
      _myInventory = inventory;
      final joined = await http.put(playerUri, headers: {'Content-Type':'application/json'}, body: jsonEncode({
        ...prior,
        'name': _name.text.trim().isEmpty ? 'Player' : _name.text.trim(),
        'joinedAt': DateTime.now().millisecondsSinceEpoch,
        'score': prior['score'] ?? 0,
        'inventory': inventory,
      }));
      if (joined.statusCode < 200 || joined.statusCode >= 300) throw Exception('Could not join room. Check database rules.');
      widget.onInventoryChanged(List<String>.from(inventory));
      _poller?.cancel();
      setState(() { _roomCode = code; _room.text = code; _status = 'Connected to room $code'; });
      await _refreshRoom();
      _poller = Timer.periodic(const Duration(seconds: 4), (_) => _refreshRoom());
    } catch (e) { if (mounted) setState(() => _status = e.toString().replaceFirst('Exception: ', '')); }
    finally { if (mounted) setState(() => _busy = false); }
  }

  Future<void> _refreshRoom() async {
    final code = _roomCode;
    if (code == null || _token == null) return;
    try {
      final responses = await Future.wait([
        http.get(_dbUri('rooms/$code/players')),
        http.get(_dbUri('rooms/$code/trades')),
      ]);
      final playersResponse = responses[0];
      final tradesResponse = responses[1];
      if (playersResponse.statusCode == 200 && mounted) {
        final rawPlayers = jsonDecode(playersResponse.body);
        final nextPlayers = rawPlayers is Map ? Map<String, dynamic>.from(rawPlayers) : <String, dynamic>{};
        final mine = _uid == null ? null : nextPlayers[_uid];
        if (mine is Map && mine['inventory'] is List) {
          final remoteInventory = (mine['inventory'] as List).map((v) => v.toString()).toList();
          if (!_sameItems(remoteInventory, _myInventory)) {
            _myInventory = remoteInventory;
            widget.onInventoryChanged(List<String>.from(remoteInventory));
          }
        }
        setState(() => _players = nextPlayers);
      }
      if (tradesResponse.statusCode == 200 && mounted) {
        final rawTrades = jsonDecode(tradesResponse.body);
        setState(() => _trades = rawTrades is Map ? Map<String, dynamic>.from(rawTrades) : {});
      }
    } catch (_) { /* keep last known state during brief network outages */ }
  }

  bool _sameItems(List<String> a, List<String> b) {
    if (a.length != b.length) return false;
    final aa = List<String>.from(a)..sort();
    final bb = List<String>.from(b)..sort();
    for (var i = 0; i < aa.length; i++) {
      if (aa[i] != bb[i]) return false;
    }
    return true;
  }

  Future<void> _openTradeDialog(String targetUid, String targetName) async {
    if (_roomCode == null || _uid == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Join the same online room as your friend first.')));
      return;
    }
    if (targetUid == _uid) return;
    final mine = _myInventory.toSet().toList()..sort();
    if (mine.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('You have no fruits to trade yet. Collect a fruit first.')));
      return;
    }
    String offered = mine.first;
    String requested = _tradeFruitOptions.firstWhere((f) => f != offered, orElse: () => _tradeFruitOptions.first);
    final create = await showDialog<bool>(
      context: context,
      builder: (context) => StatefulBuilder(builder: (context, setDialogState) => AlertDialog(
        title: Text('Trade with $targetName'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Choose one fruit to give and one fruit you want in return.'),
          const SizedBox(height: 12),
          DropdownButtonFormField<String>(
            value: offered,
            decoration: const InputDecoration(labelText: 'Your fruit', border: OutlineInputBorder()),
            items: mine.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
            onChanged: (v) => setDialogState(() {
              if (v != null) {
                offered = v;
                if (requested == offered) requested = _tradeFruitOptions.firstWhere((f) => f != offered, orElse: () => offered);
              }
            }),
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: requested,
            decoration: const InputDecoration(labelText: 'Fruit you want', border: OutlineInputBorder()),
            items: _tradeFruitOptions.where((f) => f != offered).map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
            onChanged: (v) { if (v != null) setDialogState(() => requested = v); },
          ),
          const SizedBox(height: 8),
          const Text('Your friend can accept only if they own the requested fruit.', style: TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Send offer')),
        ],
      )),
    );
    if (create == true) await _createTradeOffer(targetUid, targetName, offered, requested);
  }

  Future<void> _createTradeOffer(String targetUid, String targetName, String offered, String requested) async {
    final code = _roomCode;
    final uid = _uid;
    if (code == null || uid == null || _token == null) return;
    if (offered == requested) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Choose two different fruits for a trade.')));
      return;
    }
    if (!_myInventory.contains(offered)) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('You no longer own that fruit. Refresh your inventory and try again.')));
      return;
    }
    try {
      final response = await http.post(
        _dbUri('rooms/$code/trades'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({
          'fromUid': uid,
          'fromName': _name.text.trim().isEmpty ? 'Player' : _name.text.trim(),
          'toUid': targetUid,
          'toName': targetName,
          'offeredFruit': offered,
          'requestedFruit': requested,
          'status': 'pending',
          'createdAt': DateTime.now().millisecondsSinceEpoch,
        }),
      );
      if (response.statusCode < 200 || response.statusCode >= 300) throw Exception('Could not send trade. Check Firebase database rules.');
      await _refreshRoom();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Trade offer sent: $offered for $requested.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  Future<void> _declineTrade(String tradeId) async {
    final code = _roomCode;
    if (code == null) return;
    try {
      final r = await http.patch(
        _dbUri('rooms/$code/trades/$tradeId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'status': 'declined', 'updatedAt': DateTime.now().millisecondsSinceEpoch}),
      );
      if (r.statusCode < 200 || r.statusCode >= 300) throw Exception('Could not decline trade.');
      await _refreshRoom();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  Future<void> _acceptTrade(String tradeId) async {
    final code = _roomCode;
    final uid = _uid;
    if (code == null || uid == null || _token == null) return;
    try {
      final offerResponse = await http.get(_dbUri('rooms/$code/trades/$tradeId'));
      if (offerResponse.statusCode != 200 || offerResponse.body == 'null') throw Exception('Trade offer no longer exists.');
      final offer = Map<String, dynamic>.from(jsonDecode(offerResponse.body) as Map);
      if (offer['status'] != 'pending' || offer['toUid'] != uid) throw Exception('This offer is no longer available for you.');

      // Read the player collection with an ETag, then use If-Match so concurrent
      // acceptances cannot both overwrite the same inventory snapshot.
      final playersResponse = await http.get(_dbUri('rooms/$code/players'), headers: {'X-Firebase-ETag': 'true'});
      if (playersResponse.statusCode != 200 || playersResponse.body == 'null') throw Exception('Could not read player inventories.');
      final etag = playersResponse.headers['etag'];
      if (etag == null || etag.isEmpty) throw Exception('The database did not provide a trade lock. Please try again.');
      final rawPlayers = jsonDecode(playersResponse.body);
      final players = rawPlayers is Map ? Map<String, dynamic>.from(rawPlayers) : <String, dynamic>{};
      final fromUid = offer['fromUid']?.toString() ?? '';
      final toUid = offer['toUid']?.toString() ?? '';
      if (fromUid.isEmpty || toUid != uid || fromUid == toUid || players[fromUid] is! Map || players[toUid] is! Map) {
        throw Exception('One of the players is no longer in the room.');
      }
      final fromPlayer = Map<String, dynamic>.from(players[fromUid] as Map);
      final toPlayer = Map<String, dynamic>.from(players[toUid] as Map);
      List<String> inventoryOf(Map<String, dynamic> player) {
        final value = player['inventory'];
        return value is List ? value.map((v) => v.toString()).toList() : <String>[];
      }
      final fromInventory = inventoryOf(fromPlayer);
      final toInventory = inventoryOf(toPlayer);
      final offered = offer['offeredFruit']?.toString() ?? '';
      final requested = offer['requestedFruit']?.toString() ?? '';
      if (!fromInventory.contains(offered)) throw Exception('The sender no longer owns $offered.');
      if (!toInventory.contains(requested)) throw Exception('You do not own $requested, so you cannot accept this trade.');
      if (offered == requested) throw Exception('This trade does not exchange different fruits.');

      fromInventory.remove(offered);
      fromInventory.add(requested);
      toInventory.remove(requested);
      toInventory.add(offered);
      players[fromUid] = {...fromPlayer, 'inventory': fromInventory};
      players[toUid] = {...toPlayer, 'inventory': toInventory};

      final update = await http.put(
        _dbUri('rooms/$code/players'),
        headers: {'Content-Type': 'application/json', 'if-match': etag},
        body: jsonEncode(players),
      );
      if (update.statusCode == 412) throw Exception('Another trade changed the inventory. Refresh and try again.');
      if (update.statusCode < 200 || update.statusCode >= 300) throw Exception('Trade failed while updating inventories.');

      final marked = await http.patch(
        _dbUri('rooms/$code/trades/$tradeId'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'status': 'accepted', 'updatedAt': DateTime.now().millisecondsSinceEpoch}),
      );
      if (marked.statusCode < 200 || marked.statusCode >= 300) {
        throw Exception('The fruits were transferred, but the offer status did not update. Refresh before trying another trade.');
      }
      _myInventory = toInventory;
      widget.onInventoryChanged(List<String>.from(toInventory));
      await _refreshRoom();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Trade complete! You received $offered and gave $requested.')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(e.toString().replaceFirst('Exception: ', ''))));
    }
  }

  Future<void> _leaveRoom() async {
    _poller?.cancel();
    final code = _roomCode;
    if (code != null && _uid != null && _token != null) {
      try { await http.delete(_dbUri('rooms/$code/players/$_uid')); } catch (_) {}
    }
    setState(() { _roomCode = null; _players = {}; _status = 'You left the room.'; });
  }

  @override
  Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(16), children: [
    Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: _mpInk, borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Row(children: [Icon(Icons.groups_rounded, color: _mpLime, size: 32), SizedBox(width: 10), Expanded(child: Text('MULTIPLAYER', style: TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.w900)))]),
      const SizedBox(height: 8), const Text('Hunt fruits together with friends in the same online room.', style: TextStyle(color: Colors.white70)),
      const SizedBox(height: 16), Text(_status, style: const TextStyle(color: _mpLime, fontWeight: FontWeight.w600)),
      const SizedBox(height: 12),
      if (_roomCode == null) ...[
        TextField(controller: _room, textCapitalization: TextCapitalization.characters, maxLength: 6, style: const TextStyle(color: Colors.white), decoration: const InputDecoration(labelText: 'Room code', labelStyle: TextStyle(color: Colors.white70), counterStyle: TextStyle(color: Colors.white54), enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.white30)), focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: _mpLime)))),
        const SizedBox(height: 8),
        Row(children: [Expanded(child: FilledButton(onPressed: _busy ? null : _createRoom, style: FilledButton.styleFrom(backgroundColor: _mpLime, foregroundColor: _mpInk), child: const Text('Create room'))), const SizedBox(width: 10), Expanded(child: OutlinedButton(onPressed: _busy ? null : _joinPressed, style: OutlinedButton.styleFrom(foregroundColor: Colors.white, side: const BorderSide(color: Colors.white54)), child: const Text('Join room')))]),
      ] else ...[
        const Text('SHARE THIS CODE WITH YOUR FRIENDS', style: TextStyle(color: Colors.white70, fontSize: 11, fontWeight: FontWeight.bold)),
        Row(children: [Expanded(child: Text(_roomCode!, style: const TextStyle(color: _mpLime, fontSize: 34, fontWeight: FontWeight.w900, letterSpacing: 5))), IconButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Tell your friends this room code.'))), icon: const Icon(Icons.share, color: Colors.white))]),
        OutlinedButton(onPressed: _leaveRoom, style: OutlinedButton.styleFrom(foregroundColor: Colors.white), child: const Text('Leave room')),
      ],
      Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: _settings, icon: const Icon(Icons.settings, color: _mpLime), label: const Text('Connection settings', style: TextStyle(color: _mpLime)))),
    ])),
    const SizedBox(height: 18),
    Row(children: [const Expanded(child: Text('PLAYERS IN ROOM', style: TextStyle(fontSize: 17, fontWeight: FontWeight.w900))), Text('${_players.length} online', style: const TextStyle(color: Colors.green, fontWeight: FontWeight.bold))]),
    const SizedBox(height: 8),
    if (_roomCode == null) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Create a room or enter a friend’s 6-character code to see each other here.')))
    else if (_players.isEmpty) const Card(child: Padding(padding: EdgeInsets.all(18), child: Text('Waiting for players…')))
    else ..._players.entries.map((e) {
      final player = e.value is Map ? Map<String, dynamic>.from(e.value as Map) : <String, dynamic>{};
      final isMe = e.key == _uid;
      final playerName = player['name']?.toString() ?? 'Player';
      final inventory = player['inventory'] is List ? (player['inventory'] as List).length : 0;
      return Card(child: ListTile(
        leading: CircleAvatar(backgroundColor: _mpLime, child: Icon(isMe ? Icons.person : Icons.sports_esports, color: _mpInk)),
        title: Text('$playerName${isMe ? ' (You)' : ''}', style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(isMe ? 'Your inventory: ${_myInventory.length} fruits' : 'Inventory: $inventory fruits'),
        trailing: isMe
            ? const Icon(Icons.circle, size: 10, color: Colors.green)
            : IconButton(tooltip: 'Trade fruits with $playerName', onPressed: () => _openTradeDialog(e.key, playerName), icon: const Icon(Icons.swap_horiz_rounded, color: _mpInk)),
      ));
    }),
    const SizedBox(height: 18),
    const Text('FRUIT TRADING', style: TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
    const SizedBox(height: 4),
    Text('Your fruits: ${_myInventory.isEmpty ? 'none yet' : _myInventory.join(', ')}', style: const TextStyle(color: Colors.black54)),
    const SizedBox(height: 8),
    if (_roomCode == null)
      const Card(child: Padding(padding: EdgeInsets.all(16), child: Text('Join an online room, then tap the swap icon beside a player to offer a fruit trade.')))
    else ...[
      const Text('INCOMING OFFERS', style: TextStyle(fontWeight: FontWeight.bold)),
      ..._trades.entries.where((e) {
        final t = e.value is Map ? Map<String, dynamic>.from(e.value as Map) : <String, dynamic>{};
        return t['toUid'] == _uid && t['status'] == 'pending';
      }).map((e) {
        final t = Map<String, dynamic>.from(e.value as Map);
        final sender = t['fromName']?.toString() ?? 'Player';
        final offered = t['offeredFruit']?.toString() ?? 'Unknown fruit';
        final requested = t['requestedFruit']?.toString() ?? 'Unknown fruit';
        return Card(child: Padding(padding: const EdgeInsets.all(8), child: Column(children: [
          ListTile(leading: const CircleAvatar(child: Icon(Icons.swap_horiz)), title: Text('$sender offers $offered'), subtitle: Text('They want your $requested')),
          Row(mainAxisAlignment: MainAxisAlignment.end, children: [
            TextButton(onPressed: () => _declineTrade(e.key), child: const Text('Decline')),
            const SizedBox(width: 8),
            FilledButton.icon(onPressed: () => _acceptTrade(e.key), icon: const Icon(Icons.check), label: const Text('Accept trade')),
          ]),
        ])));
      }),
      if (!_trades.entries.any((e) {
        final t = e.value is Map ? Map<String, dynamic>.from(e.value as Map) : <String, dynamic>{};
        return t['toUid'] == _uid && t['status'] == 'pending';
      }))
        const Card(child: Padding(padding: EdgeInsets.all(14), child: Text('No incoming offers right now. Tap the swap icon beside a player to send one.'))),
      const SizedBox(height: 8),
      const Text('YOUR SENT OFFERS', style: TextStyle(fontWeight: FontWeight.bold)),
      ..._trades.entries.where((e) {
        final t = e.value is Map ? Map<String, dynamic>.from(e.value as Map) : <String, dynamic>{};
        return t['fromUid'] == _uid;
      }).map((e) {
        final t = Map<String, dynamic>.from(e.value as Map);
        final status = t['status']?.toString() ?? 'unknown';
        return Card(child: ListTile(
          leading: const Icon(Icons.outbox_outlined),
          title: Text('${t['offeredFruit'] ?? 'Fruit'} for ${t['requestedFruit'] ?? 'fruit'}'),
          subtitle: Text('To ${t['toName'] ?? 'Player'} • ${status.toUpperCase()}'),
          trailing: status == 'pending' ? IconButton(tooltip: 'Cancel offer', onPressed: () => _declineTrade(e.key), icon: const Icon(Icons.close)) : null,
        ));
      }),
    ],
    const SizedBox(height: 12),
    const Text('Trade details sync through the room database. Use Firebase Realtime Database rules that restrict players to their own profile and trade requests before using this with public players; a trusted backend is needed for strong anti-cheat protection.', style: TextStyle(color: Colors.black54, fontSize: 12)),
  ]);
}
